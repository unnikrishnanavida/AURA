class FileSystemError(Exception):
    pass
