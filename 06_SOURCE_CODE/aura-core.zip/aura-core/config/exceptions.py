class ConfigError(Exception):
    pass
