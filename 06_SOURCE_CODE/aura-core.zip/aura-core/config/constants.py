CONFIG_ROOT = "aura"
