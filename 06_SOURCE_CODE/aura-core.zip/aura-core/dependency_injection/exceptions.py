class DIError(Exception):
    pass
