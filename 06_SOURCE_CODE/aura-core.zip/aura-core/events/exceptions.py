class EventError(Exception):
    pass
