class DiagnosticsError(Exception):
    pass
