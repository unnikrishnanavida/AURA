class EvictionPolicy:
    pass
