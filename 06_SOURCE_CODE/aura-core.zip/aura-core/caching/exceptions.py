class CacheError(Exception):
    pass
