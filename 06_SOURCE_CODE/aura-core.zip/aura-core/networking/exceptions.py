class NetworkError(Exception):
    pass
