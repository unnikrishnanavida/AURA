class ConcurrencyError(Exception):
    pass
