class LoggingError(Exception):
    pass
