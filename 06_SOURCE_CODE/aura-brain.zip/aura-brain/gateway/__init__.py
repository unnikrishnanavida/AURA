"""Package marker for gateway."""
