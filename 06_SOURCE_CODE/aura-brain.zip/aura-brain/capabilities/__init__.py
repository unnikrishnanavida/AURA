"""Package marker for capabilities."""
