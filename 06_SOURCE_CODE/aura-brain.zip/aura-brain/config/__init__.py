"""Package marker for config."""
