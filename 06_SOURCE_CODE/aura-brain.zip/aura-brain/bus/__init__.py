"""Package marker for bus."""
