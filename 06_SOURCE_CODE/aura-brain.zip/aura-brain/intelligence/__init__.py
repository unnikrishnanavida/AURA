"""Package marker for intelligence."""
