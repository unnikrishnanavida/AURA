"""Package marker for knowledge."""
