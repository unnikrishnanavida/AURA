"""
AURA Brain Engine

Kernel Bootstrap

Responsible for creating and preparing the kernel.
"""

from __future__ import annotations

from .context import KernelContext
from .dependency_container import DependencyContainer
from .models import KernelInfo
from .service_provider import ServiceProvider
from .state import KernelState
from .version import KernelVersion


class Bootstrap:
    """Creates the kernel foundation."""

    def __init__(self) -> None:
        self._container = DependencyContainer()

    @property
    def container(self) -> DependencyContainer:
        return self._container

    def load_configuration(self) -> None:
        """
        Load configuration.

        Future:
        - YAML
        - JSON
        - Environment Variables
        - Secrets
        """
        pass

    def create_context(self) -> KernelContext:
        """Create the initial kernel context."""

        return KernelContext(
            state=KernelState.CREATED,
            version=KernelVersion(),
            info=KernelInfo(),
        )

    def configure_services(self) -> None:
        """Register all kernel services."""
        ServiceProvider(self._container).configure()

    def bootstrap(self) -> tuple[DependencyContainer, KernelContext]:
        """Bootstrap the kernel."""

        self.load_configuration()

        self.configure_services()

        context = self.create_context()

        return self._container, context