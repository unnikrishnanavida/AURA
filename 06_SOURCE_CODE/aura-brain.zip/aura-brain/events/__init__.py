"""Package marker for events."""
