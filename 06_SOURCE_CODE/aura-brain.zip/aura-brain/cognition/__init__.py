"""Package marker for cognition."""
