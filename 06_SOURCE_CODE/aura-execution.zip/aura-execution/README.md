﻿# AURA Execution

The AURA Execution Engine is responsible for safely translating executable
plans and actions into controlled runtime operations.

## Responsibilities

- Execution lifecycle
- Action preparation and dispatch
- Capability and tool resolution
- Permission and approval enforcement
- Safety analysis and execution gates
- Sandboxed execution
- Concurrency management
- Transactions and compensation
- Checkpointing and resume
- Failure classification and recovery
- State validation
- Observation
- Provenance
- Replay
- Telemetry
- Planning, reasoning, memory and learning integration

## Architectural rule

This repository must prioritize genuine functionality over file count.

Do not generate filler methods, artificial extension surfaces, duplicate
managers, numbered operations, or generic wrappers merely to increase code
volume.

Every implementation must have a clear responsibility and behavioral tests.
